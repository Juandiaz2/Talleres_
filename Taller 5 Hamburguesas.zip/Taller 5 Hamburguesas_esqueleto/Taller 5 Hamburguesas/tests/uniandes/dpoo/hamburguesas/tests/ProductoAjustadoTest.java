package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoAjustadoTest
{
    private ProductoMenu base;
    private ProductoAjustado ajustado;
    private Ingrediente queso;
    private Ingrediente tocineta;
    private Ingrediente tomate;

    @BeforeEach
    void setUp() throws Exception
    {
        base = new ProductoMenu("Hamburguesa", 10000);
        ajustado = new ProductoAjustado(base);
        queso = new Ingrediente("Queso", 2000);
        tocineta = new Ingrediente("Tocineta", 3000);
        tomate = new Ingrediente("Tomate", 1000);
    }

    @SuppressWarnings("unchecked")
    private void agregarIngrediente(Ingrediente ingrediente) throws Exception
    {
        Field campo = ProductoAjustado.class.getDeclaredField("agregados");
        campo.setAccessible(true);
        ArrayList<Ingrediente> lista = (ArrayList<Ingrediente>) campo.get(ajustado);
        lista.add(ingrediente);
    }

    @SuppressWarnings("unchecked")
    private void eliminarIngrediente(Ingrediente ingrediente) throws Exception
    {
        Field campo = ProductoAjustado.class.getDeclaredField("eliminados");
        campo.setAccessible(true);
        ArrayList<Ingrediente> lista = (ArrayList<Ingrediente>) campo.get(ajustado);
        lista.add(ingrediente);
    }

    @Test
    void testGetNombre()
    {
        assertEquals("Hamburguesa", ajustado.getNombre());
    }

    @Test
    void testGetPrecioSinCambios()
    {
        assertEquals(10000, ajustado.getPrecio());
    }

    @Test
    void testGetPrecioConAgregados() throws Exception
    {
        agregarIngrediente(queso);
        agregarIngrediente(tocineta);
        assertEquals(15000, ajustado.getPrecio());
    }

    @Test
    void testGetPrecioEliminarNoReducePrecio() throws Exception
    {
        eliminarIngrediente(tomate);

        assertEquals(10000, ajustado.getPrecio());
    }

    @Test
    void testGenerarTextoFactura() throws Exception
    {
        agregarIngrediente(queso);
        eliminarIngrediente(tomate);

        String texto = ajustado.generarTextoFactura();

        assertTrue(texto.contains("Hamburguesa"));
        assertTrue(texto.contains("+Queso"));
        assertTrue(texto.contains("-Tomate"));
        assertTrue(texto.contains("12000"));
    }
}
/**
 * Las pruebas asociadas al precio en esta clase pueden fallar debido a que
 * la implementación original de ProductoAjustado tiene el método getPrecio()
 * incompleto, retornando siempre 0. Debido a esto, los tests fallan en la corrida.
 */