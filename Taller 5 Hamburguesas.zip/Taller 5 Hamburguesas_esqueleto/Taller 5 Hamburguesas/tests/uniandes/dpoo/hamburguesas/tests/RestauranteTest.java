package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.IngredienteRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoFaltanteException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

public class RestauranteTest
{
    private Restaurante restaurante;

    @BeforeEach
    void setUp() throws Exception
    {
        restaurante = new Restaurante();
    }

    private File crearArchivoTemporal(String nombre, String contenido) throws IOException
    {
        File archivo = new File(nombre);
        FileWriter writer = new FileWriter(archivo);
        writer.write(contenido);
        writer.close();
        return archivo;
    }

    @Test
    void testConstructor()
    {
        assertNotNull(restaurante.getPedidos());
        assertNotNull(restaurante.getIngredientes());
        assertNotNull(restaurante.getMenuBase());
        assertNotNull(restaurante.getMenuCombos());
        assertNull(restaurante.getPedidoEnCurso());
    }

    @Test
    void testIniciarPedido() throws Exception
    {
        restaurante.iniciarPedido("David", "Calle 10");
        assertNotNull(restaurante.getPedidoEnCurso());
        assertEquals("David", restaurante.getPedidoEnCurso().getNombreCliente());
    }

    @Test
    void testIniciarPedidoConPedidoEnCurso() throws Exception
    {
        restaurante.iniciarPedido("David", "Calle 10");

        assertThrows(YaHayUnPedidoEnCursoException.class, () -> {
            restaurante.iniciarPedido("Juan", "Calle 20");
        });
    }

    @Test
    void testCerrarSinPedidoEnCurso()
    {
        assertThrows(NoHayPedidoEnCursoException.class, () -> {
            restaurante.cerrarYGuardarPedido();
        });
    }

    @Test
    void testCargarInformacionRestaurante() throws Exception
    {
        File ingredientes = crearArchivoTemporal("ingredientes_test.txt",
                "Queso;2000\nTocineta;3000\n");

        File menu = crearArchivoTemporal("menu_test.txt",
                "Hamburguesa;10000\nPapas;5000\n");

        File combos = crearArchivoTemporal("combos_test.txt",
                "Combo1;10%;Hamburguesa;Papas\n");

        restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);

        assertEquals(2, restaurante.getIngredientes().size());
        assertEquals(2, restaurante.getMenuBase().size());
        assertEquals(1, restaurante.getMenuCombos().size());

        ingredientes.delete();
        menu.delete();
        combos.delete();
    }

    @Test
    void testIngredienteRepetido() throws Exception
    {
        File ingredientes = crearArchivoTemporal("ingredientes_rep.txt",
                "Queso;2000\nQueso;3000\n");

        File menu = crearArchivoTemporal("menu_ok.txt",
                "Hamburguesa;10000\n");

        File combos = crearArchivoTemporal("combos_ok.txt",
                "Combo1;10%;Hamburguesa\n");

        assertThrows(IngredienteRepetidoException.class, () -> {
            restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);
        });

        ingredientes.delete();
        menu.delete();
        combos.delete();
    }

    @Test
    void testProductoRepetidoEnMenu() throws Exception
    {
        File ingredientes = crearArchivoTemporal("ingredientes_ok2.txt",
                "Queso;2000\n");

        File menu = crearArchivoTemporal("menu_rep.txt",
                "Hamburguesa;10000\nHamburguesa;12000\n");

        File combos = crearArchivoTemporal("combos_ok2.txt",
                "Combo1;10%;Hamburguesa\n");

        assertThrows(ProductoRepetidoException.class, () -> {
            restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);
        });

        ingredientes.delete();
        menu.delete();
        combos.delete();
    }

    @Test
    void testProductoFaltanteEnCombo() throws Exception
    {
        File ingredientes = crearArchivoTemporal("ingredientes_ok3.txt",
                "Queso;2000\n");

        File menu = crearArchivoTemporal("menu_ok3.txt",
                "Hamburguesa;10000\n");

        File combos = crearArchivoTemporal("combos_faltante.txt",
                "Combo1;10%;Hamburguesa;Papas\n");

        assertThrows(ProductoFaltanteException.class, () -> {
            restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);
        });

        ingredientes.delete();
        menu.delete();
        combos.delete();
    }

    @Test
    void testComboRepetido() throws Exception
    {
        File ingredientes = crearArchivoTemporal("ingredientes_ok4.txt",
                "Queso;2000\n");

        File menu = crearArchivoTemporal("menu_ok4.txt",
                "Hamburguesa;10000\nPapas;5000\n");

        File combos = crearArchivoTemporal("combos_rep.txt",
                "Combo1;10%;Hamburguesa;Papas\nCombo1;20%;Hamburguesa\n");

        assertThrows(ProductoRepetidoException.class, () -> {
            restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);
        });

        ingredientes.delete();
        menu.delete();
        combos.delete();
    }
}