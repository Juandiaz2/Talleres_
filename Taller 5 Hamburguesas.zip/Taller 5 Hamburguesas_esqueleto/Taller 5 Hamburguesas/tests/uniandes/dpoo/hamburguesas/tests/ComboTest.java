package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest
{
    private Combo combo;

    @BeforeEach
    void setUp() throws Exception
    {
        ProductoMenu hamburguesa = new ProductoMenu("Hamburguesa", 10000);
        ProductoMenu papas = new ProductoMenu("Papas", 5000);
        ProductoMenu gaseosa = new ProductoMenu("Gaseosa", 3000);

        ArrayList<ProductoMenu> items = new ArrayList<>();
        items.add(hamburguesa);
        items.add(papas);
        items.add(gaseosa);

        combo = new Combo("Combo especial", 0.9, items);
    }

    @Test
    void testGetNombre()
    {
        assertEquals("Combo especial", combo.getNombre());
    }

    @Test
    void testGetPrecio()
    {
        assertEquals(16200, combo.getPrecio());
    }

    @Test
    void testGenerarTextoFactura()
    {
        String esperado = "Combo Combo especial\n"
                        + " Descuento: 0.9\n"
                        + "            16200\n";

        assertEquals(esperado, combo.generarTextoFactura());
    }
}