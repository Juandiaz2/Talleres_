package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.nio.file.Files;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class PedidoTest
{
    private Pedido pedido;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;

    @BeforeEach
    void setUp() throws Exception
    {
        pedido = new Pedido("Juan", "Cra 1 # 1");
        hamburguesa = new ProductoMenu("Hamburguesa", 10000);
        papas = new ProductoMenu("Papas", 5000);
    }

    @Test
    void testGetIdPedido()
    {
        assertTrue(pedido.getIdPedido() >= 0);
    }

    @Test
    void testGetNombreCliente()
    {
        assertEquals("Juan", pedido.getNombreCliente());
    }

    @Test
    void testAgregarProductoYPrecioTotal()
    {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);

        assertEquals(17850, pedido.getPrecioTotalPedido());
    }

    @Test
    void testGenerarTextoFactura()
    {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);

        String esperado = "Cliente: Juan\n"
                        + "Dirección: Cra 1 # 1\n"
                        + "----------------\n"
                        + "Hamburguesa\n"
                        + "            10000\n"
                        + "Papas\n"
                        + "            5000\n"
                        + "----------------\n"
                        + "Precio Neto:  15000\n"
                        + "IVA:          2850\n"
                        + "Precio Total: 17850\n";

        assertEquals(esperado, pedido.generarTextoFactura());
    }

    @Test
    void testGuardarFactura() throws Exception
    {
        pedido.agregarProducto(hamburguesa);

        File archivo = new File("factura_test.txt");
        pedido.guardarFactura(archivo);

        assertTrue(archivo.exists());

        String contenido = Files.readString(archivo.toPath());
        assertEquals(pedido.generarTextoFactura(), contenido);

        archivo.delete();
    }
}