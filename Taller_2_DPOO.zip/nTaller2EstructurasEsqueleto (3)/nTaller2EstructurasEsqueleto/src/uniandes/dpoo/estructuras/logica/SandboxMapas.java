package uniandes.dpoo.estructuras.logica;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class SandboxMapas
{
    private Map<String, String> mapaCadenas;

    public SandboxMapas( )
    {
        mapaCadenas = new HashMap<String, String>( );
    }

    public List<String> getValoresComoLista( )
    {
        List<String> valores = new ArrayList<String>( );

        for( String v : mapaCadenas.values( ) )
        {
            valores.add( v );
        }

        for( int i = 0; i < valores.size( ) - 1; i++ )
        {
            int minIndex = i;
            for( int j = i + 1; j < valores.size( ); j++ )
            {
                if( valores.get( j ).compareTo( valores.get( minIndex ) ) < 0 )
                {
                    minIndex = j;
                }
            }

            String tmp = valores.get( i );
            valores.set( i, valores.get( minIndex ) );
            valores.set( minIndex, tmp );
        }

        return valores;
    }

    public List<String> getLlavesComoListaInvertida( )
    {
        List<String> llaves = new ArrayList<String>( );

        for( String k : mapaCadenas.keySet( ) )
        {
            llaves.add( k );
        }

        for( int i = 0; i < llaves.size( ) - 1; i++ )
        {
            int maxIndex = i;
            for( int j = i + 1; j < llaves.size( ); j++ )
            {
                if( llaves.get( j ).compareTo( llaves.get( maxIndex ) ) > 0 )
                {
                    maxIndex = j;
                }
            }

            String tmp = llaves.get( i );
            llaves.set( i, llaves.get( maxIndex ) );
            llaves.set( maxIndex, tmp );
        }

        return llaves;
    }

    public String getPrimera( )
    {
        if( mapaCadenas.isEmpty( ) )
        {
            return null;
        }

        String primera = null;
        for( String k : mapaCadenas.keySet( ) )
        {
            if( primera == null || k.compareTo( primera ) < 0 )
            {
                primera = k;
            }
        }
        return primera;
    }

    public String getUltima( )
    {
        if( mapaCadenas.isEmpty( ) )
        {
            return null;
        }

        String ultima = null;
        for( String v : mapaCadenas.values( ) )
        {
            if( ultima == null || v.compareTo( ultima ) > 0 )
            {
                ultima = v;
            }
        }
        return ultima;
    }

    public Collection<String> getLlaves( )
    {
        List<String> llavesMayus = new ArrayList<String>( );
        for( String k : mapaCadenas.keySet( ) )
        {
            if( k != null )
            {
                llavesMayus.add( k.toUpperCase( ) );
            }
            else
            {
                llavesMayus.add( "null" );
            }
        }
        return llavesMayus;
    }

    public int getCantidadCadenasDiferentes( )
    {
        List<String> unicos = new ArrayList<String>( );

        for( String v : mapaCadenas.values( ) )
        {
            boolean existe = false;
            for( int i = 0; i < unicos.size( ); i++ )
            {
                if( unicos.get( i ).equals( v ) )
                {
                    existe = true;
                    break;
                }
            }
            if( !existe )
            {
                unicos.add( v );
            }
        }

        return unicos.size( );
    }

    public void agregarCadena( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }

        String llave = invertir( cadena );
        mapaCadenas.put( llave, cadena );
    }

    public void eliminarCadenaConLLave( String llave )
    {
        mapaCadenas.remove( llave );
    }

    public void eliminarCadenaConValor( String valor )
    {
        if( valor == null )
        {
            valor = "null";
        }

        List<String> llavesAEliminar = new ArrayList<String>( );
        for( Map.Entry<String, String> entry : mapaCadenas.entrySet( ) )
        {
            if( entry.getValue( ).equals( valor ) )
            {
                llavesAEliminar.add( entry.getKey( ) );
            }
        }

        for( int i = 0; i < llavesAEliminar.size( ); i++ )
        {
            mapaCadenas.remove( llavesAEliminar.get( i ) );
        }
    }

    public void reiniciarMapaCadenas( List<Object> objetos )
    {
        mapaCadenas.clear( );

        if( objetos == null )
        {
            return;
        }

        for( Object obj : objetos )
        {
            String s = ( obj == null ) ? "null" : obj.toString( );
            String llave = invertir( s );
            mapaCadenas.put( llave, s );
        }
    }

    public void volverMayusculas( )
    {
        Map<String, String> nuevo = new HashMap<String, String>( );

        for( Map.Entry<String, String> entry : mapaCadenas.entrySet( ) )
        {
            String llave = entry.getKey( );
            String valor = entry.getValue( );

            if( llave == null ) llave = "null";
            if( valor == null ) valor = "null";

            nuevo.put( llave.toUpperCase( ), valor );
        }

        mapaCadenas.clear( );
        mapaCadenas.putAll( nuevo );
    }

    public boolean compararValores( String[] otroArreglo )
    {
        if( otroArreglo == null )
        {
            return false;
        }

        for( int i = 0; i < otroArreglo.length; i++ )
        {
            String buscado = otroArreglo[ i ];
            boolean encontrado = false;

            for( String v : mapaCadenas.values( ) )
            {
                if( v.equals( buscado ) )
                {
                    encontrado = true;
                    break;
                }
            }

            if( !encontrado )
            {
                return false;
            }
        }

        return true;
    }

    private String invertir( String s )
    {
        String invertida = "";
        for( int i = s.length( ) - 1; i >= 0; i-- )
        {
            invertida += s.charAt( i );
        }
        return invertida;
    }
}

