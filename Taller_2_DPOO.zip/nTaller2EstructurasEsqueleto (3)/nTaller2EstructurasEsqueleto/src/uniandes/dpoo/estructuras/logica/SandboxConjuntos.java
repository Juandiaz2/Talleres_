package uniandes.dpoo.estructuras.logica;

import java.util.Collection;
import java.util.List;
import java.util.NavigableSet;
import java.util.TreeSet;
import java.util.ArrayList;

public class SandboxConjuntos
{
    private NavigableSet<String> arbolCadenas;

    public SandboxConjuntos( )
    {
        arbolCadenas = new TreeSet<String>( );
    }

    public List<String> getCadenasComoLista( )
    {
        List<String> lista = new ArrayList<String>();
        for( String s : arbolCadenas )
        {
            lista.add( s );
        }
        return lista;
    }

    public List<String> getCadenasComoListaInvertida( )
    {
        List<String> lista = new ArrayList<String>();
        for( String s : arbolCadenas.descendingSet() )
        {
            lista.add( s );
        }
        return lista;
    }

    public String getPrimera( )
    {
        if( arbolCadenas.isEmpty() )
        {
            return null;
        }
        return arbolCadenas.first();
    }

    public String getUltima( )
    {
        if( arbolCadenas.isEmpty() )
        {
            return null;
        }
        return arbolCadenas.last();
    }

    public Collection<String> getSiguientes( String cadena )
    {
        return arbolCadenas.tailSet( cadena, true );
    }

    public int getCantidadCadenas( )
    {
        return arbolCadenas.size();
    }

    public void agregarCadena( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }
        arbolCadenas.add( cadena );
    }

    public void eliminarCadena( String cadena )
    {
        arbolCadenas.remove( cadena );
    }

    public void eliminarCadenaSinMayusculasOMinusculas( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }

        TreeSet<String> eliminar = new TreeSet<String>();
        for( String s : arbolCadenas )
        {
            if( s.equalsIgnoreCase( cadena ) )
            {
                eliminar.add( s );
            }
        }

        for( String s : eliminar )
        {
            arbolCadenas.remove( s );
        }
    }

    public void eliminarPrimera( )
    {
        if( !arbolCadenas.isEmpty() )
        {
            arbolCadenas.pollFirst();
        }
    }

    public void reiniciarConjuntoCadenas( List<Object> objetos )
    {
        arbolCadenas.clear();

        if( objetos == null )
        {
            return;
        }

        for( Object obj : objetos )
        {
            String s = ( obj == null ) ? "null" : obj.toString();
            arbolCadenas.add( s );
        }
    }

    public void volverMayusculas( )
    {
        TreeSet<String> nuevo = new TreeSet<String>();

        for( String s : arbolCadenas )
        {
            if( s != null )
            {
                nuevo.add( s.toUpperCase() );
            }
            else
            {
                nuevo.add( "null" );
            }
        }

        arbolCadenas.clear();
        arbolCadenas.addAll( nuevo );
    }

    public TreeSet<String> invertirCadenas( )
    {
        TreeSet<String> invertido = new TreeSet<String>( arbolCadenas.descendingSet().comparator() );

        for( String s : arbolCadenas.descendingSet() )
        {
            invertido.add( s );
        }

        return invertido;
    }

    public boolean compararElementos( String[] otroArreglo )
    {
        if( otroArreglo == null )
        {
            return false;
        }

        for( int i = 0; i < otroArreglo.length; i++ )
        {
            if( !arbolCadenas.contains( otroArreglo[ i ] ) )
            {
                return false;
            }
        }
        return true;
    }
}

