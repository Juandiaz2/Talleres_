package uniandes.dpoo.estructuras.logica;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;

public class SandboxListas
{
    private List<Integer> listaEnteros;
    private List<String> listaCadenas;

    public SandboxListas( )
    {
        listaEnteros = new ArrayList<Integer>( );
        listaCadenas = new LinkedList<String>( );
    }

    public List<Integer> getCopiaEnteros( )
    {
        List<Integer> copia = new ArrayList<Integer>( );
        for( Integer v : listaEnteros )
        {
            copia.add( v );
        }
        return copia;
    }

    public List<String> getCopiaCadenas( )
    {
        List<String> copia = new LinkedList<String>( );
        for( int i = 0; i < listaCadenas.size( ); i++ )
        {
            copia.add( listaCadenas.get( i ) );
        }
        return copia;
    }

    public int[] getEnterosComoArreglo( )
    {
        int[] arreglo = new int[ listaEnteros.size( ) ];
        for( int i = 0; i < listaEnteros.size( ); i++ )
        {
            arreglo[ i ] = listaEnteros.get( i );
        }
        return arreglo;
    }

    public int getCantidadEnteros( )
    {
        return listaEnteros.size( );
    }

    public int getCantidadCadenas( )
    {
        return listaCadenas.size( );
    }

    public void agregarEntero( int entero )
    {
        listaEnteros.add( entero );
    }

    public void agregarCadena( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }
        listaCadenas.add( cadena );
    }

    public void eliminarEntero( int valor )
    {
        Iterator<Integer> it = listaEnteros.iterator( );
        while( it.hasNext( ) )
        {
            Integer v = it.next( );
            if( v != null && v.intValue( ) == valor )
            {
                it.remove( );
            }
        }
    }

    public void eliminarCadena( String cadena )
    {
        Iterator<String> it = listaCadenas.iterator( );
        while( it.hasNext( ) )
        {
            String s = it.next( );
            if( s != null && s.equals( cadena ) )
            {
                it.remove( );
            }
        }
    }

    public void insertarEntero( int entero, int posicion )
    {
        if( posicion < 0 )
        {
            listaEnteros.add( 0, entero );
        }
        else if( posicion >= listaEnteros.size( ) )
        {
            listaEnteros.add( entero );
        }
        else
        {
            listaEnteros.add( posicion, entero );
        }
    }

    public void eliminarEnteroPorPosicion( int posicion )
    {
        if( posicion < 0 || posicion >= listaEnteros.size( ) )
        {
            return;
        }
        listaEnteros.remove( posicion );
    }

    public void reiniciarArregloEnteros( double[] valores )
    {
        listaEnteros.clear( );

        if( valores == null )
        {
            return;
        }

        for( int i = 0; i < valores.length; i++ )
        {
            listaEnteros.add( (int) valores[ i ] );
        }
    }

    public void reiniciarArregloCadenas( List<Object> objetos )
    {
        listaCadenas.clear( );

        if( objetos == null )
        {
            return;
        }

        for( Object obj : objetos )
        {
            String s = ( obj == null ) ? "null" : obj.toString( );
            listaCadenas.add( s );
        }
    }

    public void volverPositivos( )
    {
        for( int i = 0; i < listaEnteros.size( ); i++ )
        {
            int v = listaEnteros.get( i );
            if( v < 0 )
            {
                listaEnteros.set( i, v * -1 );
            }
        }
    }

    public void organizarEnteros( )
    {
        for( int i = 0; i < listaEnteros.size( ) - 1; i++ )
        {
            int maxIndex = i;
            for( int j = i + 1; j < listaEnteros.size( ); j++ )
            {
                if( listaEnteros.get( j ) > listaEnteros.get( maxIndex ) )
                {
                    maxIndex = j;
                }
            }

            Integer tmp = listaEnteros.get( i );
            listaEnteros.set( i, listaEnteros.get( maxIndex ) );
            listaEnteros.set( maxIndex, tmp );
        }
    }

    public void organizarCadenas( )
    {
        for( int i = 0; i < listaCadenas.size( ) - 1; i++ )
        {
            int minIndex = i;
            for( int j = i + 1; j < listaCadenas.size( ); j++ )
            {
                if( listaCadenas.get( j ).compareTo( listaCadenas.get( minIndex ) ) < 0 )
                {
                    minIndex = j;
                }
            }

            String tmp = listaCadenas.get( i );
            listaCadenas.set( i, listaCadenas.get( minIndex ) );
            listaCadenas.set( minIndex, tmp );
        }
    }

    public int contarApariciones( int valor )
    {
        int count = 0;
        for( Integer v : listaEnteros )
        {
            if( v != null && v.intValue( ) == valor )
            {
                count++;
            }
        }
        return count;
    }

    public int contarApariciones( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }

        int count = 0;
        for( String s : listaCadenas )
        {
            if( s != null && s.equalsIgnoreCase( cadena ) )
            {
                count++;
            }
        }
        return count;
    }

    public int contarEnterosRepetidos( )
    {
        int repetidos = 0;

        for( int i = 0; i < listaEnteros.size( ); i++ )
        {
            int v = listaEnteros.get( i );

            boolean yaContado = false;
            for( int k = 0; k < i; k++ )
            {
                if( listaEnteros.get( k ) == v )
                {
                    yaContado = true;
                    break;
                }
            }
            if( yaContado )
            {
                continue;
            }

            int count = 0;
            for( int j = 0; j < listaEnteros.size( ); j++ )
            {
                if( listaEnteros.get( j ) == v )
                {
                    count++;
                    if( count > 1 )
                    {
                        repetidos++;
                        break;
                    }
                }
            }
        }

        return repetidos;
    }

    public boolean compararArregloEnteros( int[] otroArreglo )
    {
        if( otroArreglo == null )
        {
            return false;
        }

        if( listaEnteros.size( ) != otroArreglo.length )
        {
            return false;
        }

        for( int i = 0; i < otroArreglo.length; i++ )
        {
            if( listaEnteros.get( i ) != otroArreglo[ i ] )
            {
                return false;
            }
        }

        return true;
    }

    public void generarEnteros( int cantidad, int minimo, int maximo )
    {
        listaEnteros.clear( );

        if( cantidad <= 0 )
        {
            return;
        }

        int rango = maximo - minimo + 1;
        if( rango <= 0 )
        {
            for( int i = 0; i < cantidad; i++ )
            {
                listaEnteros.add( minimo );
            }
            return;
        }

        for( int i = 0; i < cantidad; i++ )
        {
            int aleatorio = (int) ( Math.random( ) * rango );
            listaEnteros.add( minimo + aleatorio );
        }
    }
}

