package uniandes.dpoo.estructuras.logica;

import java.util.HashMap;

public class SandboxArreglos
{
    private int[] arregloEnteros;
    private String[] arregloCadenas;

    public SandboxArreglos( )
    {
        arregloEnteros = new int[]{};
        arregloCadenas = new String[]{};
    }

    public int[] getCopiaEnteros( )
    {
        int[] copia = new int[arregloEnteros.length];
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            copia[ i ] = arregloEnteros[ i ];
        }
        return copia;
    }

    public String[] getCopiaCadenas( )
    {
        String[] copia = new String[arregloCadenas.length];
        for( int i = 0; i < arregloCadenas.length; i++ )
        {
            copia[ i ] = arregloCadenas[ i ];
        }
        return copia;
    }

    public int getCantidadEnteros( )
    {
        return arregloEnteros.length;
    }

    public int getCantidadCadenas( )
    {
        return arregloCadenas.length;
    }

    public void agregarEntero( int entero )
    {
        int[] nuevo = new int[ arregloEnteros.length + 1 ];
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            nuevo[ i ] = arregloEnteros[ i ];
        }
        nuevo[ nuevo.length - 1 ] = entero;
        arregloEnteros = nuevo;
    }

    public void agregarCadena( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }

        String[] nuevo = new String[ arregloCadenas.length + 1 ];
        for( int i = 0; i < arregloCadenas.length; i++ )
        {
            nuevo[ i ] = arregloCadenas[ i ];
        }
        nuevo[ nuevo.length - 1 ] = cadena;
        arregloCadenas = nuevo;
    }

    public void eliminarEntero( int valor )
    {
        int countEliminar = 0;
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( arregloEnteros[ i ] == valor )
            {
                countEliminar++;
            }
        }

        if( countEliminar == 0 )
        {
            return;
        }

        int[] nuevo = new int[ arregloEnteros.length - countEliminar ];
        int j = 0;
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( arregloEnteros[ i ] != valor )
            {
                nuevo[ j ] = arregloEnteros[ i ];
                j++;
            }
        }
        arregloEnteros = nuevo;
    }

    public void eliminarCadena( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }

        int countEliminar = 0;
        for( int i = 0; i < arregloCadenas.length; i++ )
        {
            if( arregloCadenas[ i ].equals( cadena ) )
            {
                countEliminar++;
            }
        }

        if( countEliminar == 0 )
        {
            return;
        }

        String[] nuevo = new String[ arregloCadenas.length - countEliminar ];
        int j = 0;
        for( int i = 0; i < arregloCadenas.length; i++ )
        {
            if( !arregloCadenas[ i ].equals( cadena ) )
            {
                nuevo[ j ] = arregloCadenas[ i ];
                j++;
            }
        }
        arregloCadenas = nuevo;
    }

    public void insertarEntero( int entero, int posicion )
    {
        int n = arregloEnteros.length;

        int pos;
        if( posicion < 0 )
        {
            pos = 0;
        }
        else if( posicion > n )
        {
            pos = n;
        }
        else
        {
            pos = posicion;
        }

        int[] nuevo = new int[ n + 1 ];

        for( int i = 0; i < pos; i++ )
        {
            nuevo[ i ] = arregloEnteros[ i ];
        }

        nuevo[ pos ] = entero;

        for( int i = pos; i < n; i++ )
        {
            nuevo[ i + 1 ] = arregloEnteros[ i ];
        }

        arregloEnteros = nuevo;
    }

    public void eliminarEnteroPorPosicion( int posicion )
    {
        if( posicion < 0 || posicion >= arregloEnteros.length )
        {
            return;
        }

        int[] nuevo = new int[ arregloEnteros.length - 1 ];
        int j = 0;
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( i != posicion )
            {
                nuevo[ j ] = arregloEnteros[ i ];
                j++;
            }
        }
        arregloEnteros = nuevo;
    }

    public void reiniciarArregloEnteros( double[] valores )
    {
        if( valores == null )
        {
            arregloEnteros = new int[]{};
            return;
        }

        int[] nuevo = new int[ valores.length ];
        for( int i = 0; i < valores.length; i++ )
        {
            nuevo[ i ] = (int) valores[ i ];
        }
        arregloEnteros = nuevo;
    }

    public void reiniciarArregloCadenas( Object[] objetos )
    {
        if( objetos == null )
        {
            arregloCadenas = new String[]{};
            return;
        }

        String[] nuevo = new String[ objetos.length ];
        for( int i = 0; i < objetos.length; i++ )
        {
            Object obj = objetos[ i ];
            nuevo[ i ] = ( obj == null ) ? "null" : obj.toString();
        }
        arregloCadenas = nuevo;
    }

    public void volverPositivos( )
    {
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( arregloEnteros[ i ] < 0 )
            {
                arregloEnteros[ i ] = arregloEnteros[ i ] * -1;
            }
        }
    }

    public void organizarEnteros( )
    {
        for( int i = 0; i < arregloEnteros.length - 1; i++ )
        {
            int minIndex = i;
            for( int j = i + 1; j < arregloEnteros.length; j++ )
            {
                if( arregloEnteros[ j ] < arregloEnteros[ minIndex ] )
                {
                    minIndex = j;
                }
            }

            int tmp = arregloEnteros[ i ];
            arregloEnteros[ i ] = arregloEnteros[ minIndex ];
            arregloEnteros[ minIndex ] = tmp;
        }
    }

    public void organizarCadenas( )
    {
        for( int i = 0; i < arregloCadenas.length - 1; i++ )
        {
            int minIndex = i;
            for( int j = i + 1; j < arregloCadenas.length; j++ )
            {
                if( arregloCadenas[ j ].compareTo( arregloCadenas[ minIndex ] ) < 0 )
                {
                    minIndex = j;
                }
            }

            String tmp = arregloCadenas[ i ];
            arregloCadenas[ i ] = arregloCadenas[ minIndex ];
            arregloCadenas[ minIndex ] = tmp;
        }
    }

    public int contarApariciones( int valor )
    {
        int count = 0;
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( arregloEnteros[ i ] == valor )
            {
                count++;
            }
        }
        return count;
    }

    public int contarApariciones( String cadena )
    {
        if( cadena == null )
        {
            cadena = "null";
        }

        int count = 0;
        for( int i = 0; i < arregloCadenas.length; i++ )
        {
            if( arregloCadenas[ i ].equalsIgnoreCase( cadena ) )
            {
                count++;
            }
        }
        return count;
    }

    public int[] buscarEntero( int valor )
    {
        int count = 0;
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( arregloEnteros[ i ] == valor )
            {
                count++;
            }
        }

        if( count == 0 )
        {
            return new int[]{};
        }

        int[] posiciones = new int[ count ];
        int j = 0;
        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( arregloEnteros[ i ] == valor )
            {
                posiciones[ j ] = i;
                j++;
            }
        }

        return posiciones;
    }

    public int[] calcularRangoEnteros( )
    {
        if( arregloEnteros.length == 0 )
        {
            return new int[]{};
        }

        int min = arregloEnteros[ 0 ];
        int max = arregloEnteros[ 0 ];

        for( int i = 1; i < arregloEnteros.length; i++ )
        {
            int v = arregloEnteros[ i ];
            if( v < min ) min = v;
            if( v > max ) max = v;
        }

        return new int[]{ min, max };
    }

    public HashMap<Integer, Integer> calcularHistograma( )
    {
        HashMap<Integer, Integer> hist = new HashMap<Integer, Integer>();

        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            int v = arregloEnteros[ i ];
            Integer llave = Integer.valueOf( v );

            if( hist.containsKey( llave ) )
            {
                hist.put( llave, hist.get( llave ) + 1 );
            }
            else
            {
                hist.put( llave, 1 );
            }
        }

        return hist;
    }

    public int contarEnterosRepetidos( )
    {
        HashMap<Integer, Integer> hist = calcularHistograma( );
        int repetidos = 0;

        for( Integer llave : hist.keySet( ) )
        {
            if( hist.get( llave ) > 1 )
            {
                repetidos++;
            }
        }

        return repetidos;
    }

    public boolean compararArregloEnteros( int[] otroArreglo )
    {
        if( otroArreglo == null )
        {
            return false;
        }

        if( arregloEnteros.length != otroArreglo.length )
        {
            return false;
        }

        for( int i = 0; i < arregloEnteros.length; i++ )
        {
            if( arregloEnteros[ i ] != otroArreglo[ i ] )
            {
                return false;
            }
        }

        return true;
    }

    public boolean mismosEnteros( int[] otroArreglo )
    {
        if( otroArreglo == null )
        {
            return false;
        }

        if( arregloEnteros.length != otroArreglo.length )
        {
            return false;
        }

        HashMap<Integer, Integer> hist1 = calcularHistograma( );
        HashMap<Integer, Integer> hist2 = new HashMap<Integer, Integer>();

        for( int i = 0; i < otroArreglo.length; i++ )
        {
            Integer llave = Integer.valueOf( otroArreglo[ i ] );
            if( hist2.containsKey( llave ) )
            {
                hist2.put( llave, hist2.get( llave ) + 1 );
            }
            else
            {
                hist2.put( llave, 1 );
            }
        }

        if( hist1.size( ) != hist2.size( ) )
        {
            return false;
        }

        for( Integer k : hist1.keySet( ) )
        {
            if( !hist2.containsKey( k ) )
            {
                return false;
            }
            if( !hist1.get( k ).equals( hist2.get( k ) ) )
            {
                return false;
            }
        }

        return true;
    }

    public void generarEnteros( int cantidad, int minimo, int maximo )
    {
        if( cantidad <= 0 )
        {
            arregloEnteros = new int[]{};
            return;
        }

        int[] nuevo = new int[ cantidad ];

        int rango = maximo - minimo + 1;
        if( rango <= 0 )
        {
            for( int i = 0; i < cantidad; i++ )
            {
                nuevo[ i ] = minimo;
            }
            arregloEnteros = nuevo;
            return;
        }

        for( int i = 0; i < cantidad; i++ )
        {
            int aleatorio = (int) ( Math.random( ) * rango );
            nuevo[ i ] = minimo + aleatorio;
        }

        arregloEnteros = nuevo;
    }
}

