package uniandes.dpoo.aerolinea.modelo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.persistencia.CentralPersistencia;
import uniandes.dpoo.aerolinea.persistencia.IPersistenciaAerolinea;
import uniandes.dpoo.aerolinea.persistencia.IPersistenciaTiquetes;
import uniandes.dpoo.aerolinea.persistencia.TipoInvalidoException;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
import uniandes.dpoo.aerolinea.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tarifas.CalculadoraTarifasTemporadaAlta;
import uniandes.dpoo.aerolinea.tarifas.CalculadoraTarifasTemporadaBaja;

public class Aerolinea
{
    private List<Avion> aviones;
    private Map<String, Ruta> rutas;
    private List<Vuelo> vuelos;
    private Map<String, Cliente> clientes;

    public Aerolinea( )
    {
        aviones = new LinkedList<Avion>( );
        rutas = new HashMap<String, Ruta>( );
        vuelos = new LinkedList<Vuelo>( );
        clientes = new HashMap<String, Cliente>( );
    }

    public void agregarRuta( Ruta ruta )
    {
        this.rutas.put( ruta.getCodigoRuta( ), ruta );
    }

    public void agregarAvion( Avion avion )
    {
        this.aviones.add( avion );
    }

    public void agregarCliente( Cliente cliente )
    {
        this.clientes.put( cliente.getIdentificador( ), cliente );
    }

    public boolean existeCliente( String identificadorCliente )
    {
        return this.clientes.containsKey( identificadorCliente );
    }

    public Cliente getCliente( String identificadorCliente )
    {
        return this.clientes.get( identificadorCliente );
    }

    public Collection<Avion> getAviones( )
    {
        return aviones;
    }

    public Collection<Ruta> getRutas( )
    {
        return rutas.values( );
    }

    public Ruta getRuta( String codigoRuta )
    {
        return rutas.get( codigoRuta );
    }

    public Collection<Vuelo> getVuelos( )
    {
        return vuelos;
    }

    public Vuelo getVuelo( String codigoRuta, String fechaVuelo )
    {
        for( Vuelo v : vuelos )
        {
            if( v.getFecha( ).equals( fechaVuelo ) && v.getRuta( ) != null && v.getRuta( ).getCodigoRuta( ).equals( codigoRuta ) )
                return v;
        }
        return null;
    }

    public Collection<Cliente> getClientes( )
    {
        return clientes.values( );
    }

    public Collection<Tiquete> getTiquetes( )
    {
        Collection<Tiquete> tiquetes = new ArrayList<Tiquete>( );
        for( Vuelo v : vuelos )
        {
            tiquetes.addAll( v.getTiquetes( ) );
        }
        return tiquetes;
    }

    public void cargarAerolinea( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException, InformacionInconsistenteException
    {
        IPersistenciaAerolinea cargador = CentralPersistencia.getPersistenciaAerolinea( tipoArchivo );
        cargador.cargarAerolinea( archivo, this );
    }

    public void salvarAerolinea( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException
    {
        IPersistenciaAerolinea salvador = CentralPersistencia.getPersistenciaAerolinea( tipoArchivo );
        salvador.salvarAerolinea( archivo, this );
    }

    public void cargarTiquetes( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException, InformacionInconsistenteException
    {
        IPersistenciaTiquetes cargador = CentralPersistencia.getPersistenciaTiquetes( tipoArchivo );
        cargador.cargarTiquetes( archivo, this );
    }

    public void salvarTiquetes( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException
    {
        IPersistenciaTiquetes cargador = CentralPersistencia.getPersistenciaTiquetes( tipoArchivo );
        cargador.salvarTiquetes( archivo, this );
    }

    public void programarVuelo( String fecha, String codigoRuta, String nombreAvion ) throws Exception
    {
        Ruta ruta = getRuta( codigoRuta );
        if( ruta == null )
            throw new Exception( "No existe una ruta con el código: " + codigoRuta );

        if( getVuelo( codigoRuta, fecha ) != null )
            throw new Exception( "Ya existe un vuelo programado para esa ruta y fecha." );

        Avion avion = buscarAvionPorNombre( nombreAvion );
        if( avion == null )
            throw new Exception( "No existe un avión con el nombre: " + nombreAvion );

        int inicioNuevo = Ruta.getHoras( ruta.getHoraSalida( ) ) * 60 + Ruta.getMinutos( ruta.getHoraSalida( ) );
        int finNuevo = Ruta.getHoras( ruta.getHoraLlegada( ) ) * 60 + Ruta.getMinutos( ruta.getHoraLlegada( ) );
        if( finNuevo <= inicioNuevo )
            finNuevo += 24 * 60;

        for( Vuelo v : vuelos )
        {
            if( !v.getFecha( ).equals( fecha ) )
                continue;

            if( v.getAvion( ) != null && v.getAvion( ).getNombre( ).equals( nombreAvion ) )
            {
                Ruta rExistente = v.getRuta( );

                int inicioExistente = Ruta.getHoras( rExistente.getHoraSalida( ) ) * 60 + Ruta.getMinutos( rExistente.getHoraSalida( ) );
                int finExistente = Ruta.getHoras( rExistente.getHoraLlegada( ) ) * 60 + Ruta.getMinutos( rExistente.getHoraLlegada( ) );
                if( finExistente <= inicioExistente )
                    finExistente += 24 * 60;

                boolean seTraslapan = inicioNuevo < finExistente && inicioExistente < finNuevo;
                if( seTraslapan )
                    throw new Exception( "El avión ya está ocupado en el intervalo de tiempo de ese vuelo." );
            }
        }

        Vuelo nuevo = new Vuelo( ruta, fecha, avion );
        vuelos.add( nuevo );
    }

    public int venderTiquetes( String identificadorCliente, String fecha, String codigoRuta, int cantidad ) throws VueloSobrevendidoException, Exception
    {
        if( cantidad <= 0 )
            throw new Exception( "La cantidad de tiquetes debe ser mayor que cero." );

        Cliente cliente = getCliente( identificadorCliente );
        if( cliente == null )
            throw new Exception( "No existe un cliente con identificador: " + identificadorCliente );

        Vuelo vuelo = getVuelo( codigoRuta, fecha );
        if( vuelo == null )
            throw new Exception( "No existe un vuelo para esa ruta y fecha." );

        int mes = extraerMes( fecha );
        CalculadoraTarifas calculadora = esTemporadaBaja( mes ) ? new CalculadoraTarifasTemporadaBaja( ) : new CalculadoraTarifasTemporadaAlta( );

        return vuelo.venderTiquetes( cliente, calculadora, cantidad );
    }

    public void registrarVueloRealizado( String fecha, String codigoRuta )
    {
        Vuelo vuelo = getVuelo( codigoRuta, fecha );
        if( vuelo == null )
            return;

        for( Cliente c : clientes.values( ) )
        {
            c.usarTiquetes( vuelo );
        }
    }

    public String consultarSaldoPendienteCliente( String identificadorCliente )
    {
        Cliente cliente = getCliente( identificadorCliente );
        if( cliente == null )
            return "0";

        int valor = cliente.calcularValorTotalTiquetes( );
        return Integer.toString( valor );
    }

    private Avion buscarAvionPorNombre( String nombreAvion )
    {
        for( Avion a : aviones )
        {
            if( a.getNombre( ).equals( nombreAvion ) )
                return a;
        }
        return null;
    }

    private boolean esTemporadaBaja( int mes )
    {
        return ( mes >= 1 && mes <= 5 ) || ( mes >= 9 && mes <= 11 );
    }

    private int extraerMes( String fecha ) throws Exception
    {
        String limpia = fecha.trim( );
        String[] partes = limpia.contains( "-" ) ? limpia.split( "-" ) : limpia.split( "/" );

        if( partes.length < 2 )
            throw new Exception( "Formato de fecha inválido: " + fecha );

        int a = Integer.parseInt( partes[ 0 ] );
        int b = Integer.parseInt( partes[ 1 ] );

        int mes = b;

        if( mes < 1 || mes > 12 )
            throw new Exception( "Mes inválido en la fecha: " + fecha );

        return mes;
    }
}