package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.LinkedList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente
{
    protected String identificador;
    protected List<Tiquete> tiquetes;

    public Cliente( String identificador )
    {
        this.identificador = identificador;
        this.tiquetes = new LinkedList<Tiquete>( );
    }

    public String getIdentificador( )
    {
        return identificador;
    }

    public abstract String getTipoCliente( );

    public void agregarTiquete( Tiquete tiquete )
    {
        tiquetes.add( tiquete );
    }

    public int calcularValorTotalTiquetes( )
    {
        int total = 0;
        for( Tiquete t : tiquetes )
        {
            if( !t.esUsado( ) )
                total += t.getTarifa( );
        }
        return total;
    }

    public void usarTiquetes( Vuelo vuelo )
    {
        for( Tiquete t : tiquetes )
        {
            if( !t.esUsado( ) && t.getVuelo( ).equals( vuelo ) )
                t.marcarComoUsado( );
        }
    }

    public List<Tiquete> getTiquetes( )
    {
        return tiquetes;
    }
}