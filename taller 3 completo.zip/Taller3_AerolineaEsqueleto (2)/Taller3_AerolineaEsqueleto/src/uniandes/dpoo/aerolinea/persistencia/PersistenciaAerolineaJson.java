package uniandes.dpoo.aerolinea.persistencia;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea
{
    @Override
    public void cargarAerolinea( String archivo, Aerolinea aerolinea ) throws IOException, InformacionInconsistenteException
    {
        JSONObject raiz = new JSONObject( new JSONTokener( new FileReader( archivo ) ) );

        JSONArray jAviones = raiz.optJSONArray( "aviones" );
        if( jAviones != null )
        {
            for( int i = 0; i < jAviones.length( ); i++ )
            {
                JSONObject a = jAviones.getJSONObject( i );
                aerolinea.agregarAvion( new Avion( a.getString( "nombre" ), a.getInt( "capacidad" ) ) );
            }
        }

        Map<String, Aeropuerto> aeropuertosPorCodigo = new HashMap<String, Aeropuerto>( );

        JSONArray jAeropuertos = raiz.optJSONArray( "aeropuertos" );
        if( jAeropuertos != null )
        {
            for( int i = 0; i < jAeropuertos.length( ); i++ )
            {
                JSONObject ap = jAeropuertos.getJSONObject( i );
                try
                {
                    Aeropuerto aero = new Aeropuerto(
                            ap.getString( "nombre" ),
                            ap.getString( "codigo" ),
                            ap.getString( "nombreCiudad" ),
                            ap.getDouble( "latitud" ),
                            ap.getDouble( "longitud" )
                    );
                    aeropuertosPorCodigo.put( aero.getCodigo( ), aero );
                }
                catch( AeropuertoDuplicadoException e )
                {
                    throw new InformacionInconsistenteException( "Aeropuerto duplicado en el archivo: " + e.getMessage( ) );
                }
            }
        }

        JSONArray jRutas = raiz.optJSONArray( "rutas" );
        if( jRutas != null )
        {
            for( int i = 0; i < jRutas.length( ); i++ )
            {
                JSONObject r = jRutas.getJSONObject( i );
                String codOrigen = r.getString( "origen" );
                String codDestino = r.getString( "destino" );

                Aeropuerto origen = aeropuertosPorCodigo.get( codOrigen );
                Aeropuerto destino = aeropuertosPorCodigo.get( codDestino );

                if( origen == null || destino == null )
                    throw new InformacionInconsistenteException( "Ruta con aeropuertos inexistentes: " + codOrigen + " -> " + codDestino );

                Ruta ruta = new Ruta( origen, destino, r.getString( "horaSalida" ), r.getString( "horaLlegada" ), r.getString( "codigoRuta" ) );
                aerolinea.agregarRuta( ruta );
            }
        }

        JSONArray jVuelos = raiz.optJSONArray( "vuelos" );
        if( jVuelos != null )
        {
            for( int i = 0; i < jVuelos.length( ); i++ )
            {
                JSONObject v = jVuelos.getJSONObject( i );

                String fecha = v.getString( "fecha" );
                String codigoRuta = v.getString( "codigoRuta" );
                String nombreAvion = v.getString( "avion" );

                if( aerolinea.getRuta( codigoRuta ) == null )
                    throw new InformacionInconsistenteException( "Vuelo con ruta inexistente: " + codigoRuta );

                if( buscarAvionPorNombre( aerolinea.getAviones( ), nombreAvion ) == null )
                    throw new InformacionInconsistenteException( "Vuelo con avión inexistente: " + nombreAvion );

                try
                {
                    aerolinea.programarVuelo( fecha, codigoRuta, nombreAvion );
                }
                catch( Exception e )
                {
                    throw new InformacionInconsistenteException( "No se pudo programar un vuelo cargado desde archivo: " + e.getMessage( ) );
                }
            }
        }
    }

    @Override
    public void salvarAerolinea( String archivo, Aerolinea aerolinea ) throws IOException
    {
        JSONObject raiz = new JSONObject( );

        JSONArray jAviones = new JSONArray( );
        for( Avion a : aerolinea.getAviones( ) )
        {
            JSONObject ja = new JSONObject( );
            ja.put( "nombre", a.getNombre( ) );
            ja.put( "capacidad", a.getCapacidad( ) );
            jAviones.put( ja );
        }
        raiz.put( "aviones", jAviones );

        Set<String> codigosAgregados = new HashSet<String>( );
        JSONArray jAeropuertos = new JSONArray( );

        for( Ruta r : aerolinea.getRutas( ) )
        {
            Aeropuerto o = r.getOrigen( );
            Aeropuerto d = r.getDestino( );

            if( !codigosAgregados.contains( o.getCodigo( ) ) )
            {
                jAeropuertos.put( aeropuertoAJson( o ) );
                codigosAgregados.add( o.getCodigo( ) );
            }
            if( !codigosAgregados.contains( d.getCodigo( ) ) )
            {
                jAeropuertos.put( aeropuertoAJson( d ) );
                codigosAgregados.add( d.getCodigo( ) );
            }
        }
        raiz.put( "aeropuertos", jAeropuertos );

        JSONArray jRutas = new JSONArray( );
        for( Ruta r : aerolinea.getRutas( ) )
        {
            JSONObject jr = new JSONObject( );
            jr.put( "codigoRuta", r.getCodigoRuta( ) );
            jr.put( "origen", r.getOrigen( ).getCodigo( ) );
            jr.put( "destino", r.getDestino( ).getCodigo( ) );
            jr.put( "horaSalida", r.getHoraSalida( ) );
            jr.put( "horaLlegada", r.getHoraLlegada( ) );
            jRutas.put( jr );
        }
        raiz.put( "rutas", jRutas );

        JSONArray jVuelos = new JSONArray( );
        for( Vuelo v : aerolinea.getVuelos( ) )
        {
            JSONObject jv = new JSONObject( );
            jv.put( "fecha", v.getFecha( ) );
            jv.put( "codigoRuta", v.getRuta( ).getCodigoRuta( ) );
            jv.put( "avion", v.getAvion( ).getNombre( ) );
            jVuelos.put( jv );
        }
        raiz.put( "vuelos", jVuelos );

        FileWriter fw = new FileWriter( archivo );
        fw.write( raiz.toString( 2 ) );
        fw.close( );
    }

    private Avion buscarAvionPorNombre( Collection<Avion> aviones, String nombreAvion )
    {
        for( Avion a : aviones )
        {
            if( a.getNombre( ).equals( nombreAvion ) )
                return a;
        }
        return null;
    }

    private JSONObject aeropuertoAJson( Aeropuerto ap )
    {
        JSONObject jap = new JSONObject( );
        jap.put( "nombre", ap.getNombre( ) );
        jap.put( "codigo", ap.getCodigo( ) );
        jap.put( "nombreCiudad", ap.getNombreCiudad( ) );
        jap.put( "latitud", ap.getLatitud( ) );
        jap.put( "longitud", ap.getLongitud( ) );
        return jap;
    }
}